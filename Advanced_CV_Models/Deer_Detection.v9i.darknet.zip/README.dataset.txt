# Deer_Detection > 2023-05-06 11:59am
https://universe.roboflow.com/cvassignment-h2ctg/deer_detection-arsmv

Provided by a Roboflow user
License: CC BY 4.0

